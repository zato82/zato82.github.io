package com.fatherfinder;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.DialogInterface;
import android.content.DialogInterface.OnCancelListener;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.Toast;

/*
 * The idea is that this activity will be the main activity and will handle
 * spawning other activities/services depending on which device is selected
 * 
 * This activity will negotiate with two services
 * the first, a bluetooth comm service, will be passed to the second, a paternity
 * test conducting service. 
 * 
 * The idea here is that the comm service has a common api that allows for any type of communication protocoll.
 * Similarly, the test service is interchangeable with future tests, without being visible to this or any other
 * activity.
 *
 */


/**
 * This is the main activity that conducts the tests and displays the results. 
 * @author skyf
 *
 */
public class ConductTest extends Activity {
	// Debugging
    private static final String TAG = "ConductTest";
    private static final boolean D = true;
    private static final boolean benchmarkBandwidth = true;
    
    // Intent request codes
    private static final int REQUEST_CONNECT_DEVICE_SECURE = 1;
    private static final int REQUEST_ENABLE_BT = 3; //TODO: Refactor this out
    private static final int REQUEST_DISCOVERABLE = 4;
    
    // Start Message
    private static final String TEST_OK = "READY";

    // Layout Views
    private Button mPatButton;
    private Button mAncButton;
    
    // Has the user/other user agreed to the test? 
    private boolean mStartTest = false;
    private boolean mOtherStartTest = false;
    private boolean mTestIsRunning = false; 
    
    private ProgressDialog testIndicator;
    private ProgressDialog connectionIndicator;
    
    //TODO: This is needed to ensure that the bluetooth is turned on. Think about refactoring into service
    // Local Bluetooth adapter
    private BluetoothAdapter mBluetoothAdapter = null;
    // Member object for the communication services
    private BluetoothService mMessageService = null; 
    // Array adapter for the conversation thread
    
	/**
	 * @see android.app.Activity#onCreate(Bundle)
	 */
	@Override protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
        if(D) Log.d(TAG, "+++ ON CREATE +++");

        // Set up the window layout
        setContentView(R.layout.main);

        // Get local Bluetooth adapter
        mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();

        // If the adapter is null, then Bluetooth is not supported
        if (mBluetoothAdapter == null) {
            Toast.makeText(this, "Bluetooth is not available", Toast.LENGTH_LONG).show();
            finish();
            return;
        }
	}
	
	//NOTE: This happens when an activity becomes visible
	@Override
    public void onStart() {
        super.onStart();
        if(D) Log.e(TAG, "++ ON START ++");

        // If BT is not on, request that it be enabled.
        // setupChat() will then be called during onActivityResult
        if (!mBluetoothAdapter.isEnabled()) {
            Intent enableIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivityForResult(enableIntent, REQUEST_ENABLE_BT);
        // Otherwise, setup the chat session
        } else {
            if (mMessageService == null) setupChat();
        }
        
        PaternityTest.start(getBaseContext()); 
        AncestryTest.start(getBaseContext());
	}
	
	@Override
    public synchronized void onResume() {
        super.onResume();
        if(D) Log.e(TAG, "+ ON RESUME +");
        
        // Performing this check in onResume() covers the case in which BT was
        // not enabled during onStart(), so we were paused to enable it...
        // onResume() will be called when ACTION_REQUEST_ENABLE activity returns.
        if (mMessageService != null) {
            // Only if the state is STATE_NONE, do we know that we haven't started already
            if (mMessageService.getState() == BluetoothService.STATE_NONE) {
              // Start the Bluetooth chat services
              mMessageService.start();
            }
        }
    }
	
	private void setupChat() {
        Log.d(TAG, "setupChat()");
        
        // Initialize the send button with a listener that for click events
        mPatButton = (Button) findViewById(R.id.button_test1);
        mPatButton.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                // Check that we're actually connected before trying anything
                if (mMessageService.getState() != BluetoothService.STATE_CONNECTED) {
                    Toast.makeText(ConductTest.this, R.string.not_connected, Toast.LENGTH_SHORT).show();
                    return;
                }
            	
            	mStartTest = true;
            	if(D) Log.d(TAG,"mStartTest: true");
            	
            	mMessageService.write(TEST_OK);
            	
            	// Are they are ready?
            	if(mOtherStartTest){
            		doTest( PaternityTest.TEST_NAME, true ); // Start the paternity test as the client
            	}
            	else{
            		if(testIndicator != null) testIndicator.dismiss(); // Tests are asynchronous so make sure we only show one indicator
            		testIndicator = ProgressDialog.show(ConductTest.this, "", "Waiting for the other party to start the test...", true, true);
            		testIndicator.setOnCancelListener(new OnCancelListener(){
						public void onCancel(DialogInterface dialog) {
							mStartTest = false;
							if(D) Log.d(TAG,"mStartTest: false");
						}
            		});
            	}
            }
        });
        mPatButton.setVisibility(View.GONE);
        
       /* UNCOMMENT FOR ANCESTRY mAncButton = (Button) findViewById(R.id.button_test2);
        mAncButton.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                doTest( AncestryTest.TEST_NAME, true ); // Start the ancestry test as the client
            }
        }); */

        // Initialize the BluetoothService to perform bluetooth connections
        if(benchmarkBandwidth){
        	mMessageService = new BluetoothServiceLogger(this, mHandler);
        }else {
        	mMessageService = new BluetoothService(this, mHandler);
        }
        
        ensureDiscoverable(); //added for the test
    }

	
	 @Override
    public synchronized void onPause() {
        super.onPause();
        if(D) Log.e(TAG, "- ON PAUSE -");
    }

    @Override
    public void onStop() {
        super.onStop();
        if(D) Log.e(TAG, "-- ON STOP --");
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        
        if(D) Log.e(TAG, "--- ON DESTROY ---");
        
        // Stop the Bluetooth chat services
        if (mMessageService != null) {
        	mMessageService.stop();
        	mMessageService = null;
        }
        
        // Kill the testing service
        PaternityTest.stop();
        AncestryTest.stop(); 
        
        if(testIndicator != null) testIndicator.dismiss();
        if(connectionIndicator != null) connectionIndicator.dismiss();
    }
    
    private void ensureDiscoverable() {
        if(D) Log.d(TAG, "ensure discoverable");
        
        // Commented out for test
        //if (mBluetoothAdapter.getScanMode() !=
        //    BluetoothAdapter.SCAN_MODE_CONNECTABLE_DISCOVERABLE) {
            Intent discoverableIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE);
            discoverableIntent.putExtra(BluetoothAdapter.EXTRA_DISCOVERABLE_DURATION, 300);
            startActivityForResult(discoverableIntent, REQUEST_DISCOVERABLE);
        //}
    }
    
    
    /**
     * Conducts a test.
     * @param test  Which test is being conducted
     * @param asClient Flag indicating if the test is conducted as client or server
     */
    // This will fire off the desired test service and connect it to the chosen device
    private void doTest(String test, boolean asClient) {
    	if(D) Log.e(TAG, "START TEST: " + test + ". As client? " + asClient);

        // Display an indicator that the test is taking place
        if(testIndicator != null) testIndicator.dismiss(); // Tests are asynchronous so make sure we only show one indicator
        testIndicator = ProgressDialog.show(this, "", "");
        
        if(!mTestIsRunning)
        	(new PerformTestThread(test, asClient)).start();
    }
    
    // Our test may take a while let it run in a different thread TODO: Think about using an async task
    class PerformTestThread extends Thread {
    	private String mTest;
    	private boolean mClient;
    	private String result;
    	public PerformTestThread(String test, boolean asClient){
    		mTest = test;
    		mClient = asClient;
    	}
    	
    	public void run(){ 
    		if(D) Log.d(TAG, "Inside the perform thread");
    		mTestIsRunning = true;

            if(mTest.equals(AncestryTest.TEST_NAME)){
            	result = AncestryTest.conductTest(mMessageService, mClient);
            }
            else if(mTest.equals(PaternityTest.TEST_NAME)){
            	result = PaternityTest.conductTest(mMessageService, mClient);
            }
            else{
            	Log.e(TAG, "Test name not recognized: " + mTest);
            	return;
            }
            
    		runOnUiThread(new Runnable(){
				public void run() {
					mTestIsRunning = false;
					testIndicator.dismiss();
	                displayResult(result);
				}
    			
    		});
    	}
    }
    
    /**
     * Displays the results of the test
     */
    private void displayResult(String m) {
    	if(m == null)
    		m = getString(R.string.something_went_wrong);
    	
    	////////// TEST CODE //////////////////
    	// Here we just add the result to the message adapter to look at later
    	//mMessageLogArrayAdapter.add(m);
    	
    	///////////////////////////////////////
    	
    	AlertDialog.Builder builder = new AlertDialog.Builder(this);
    	//builder.setView(myMsg);
    	builder.setMessage(m);
    	builder.setPositiveButton("EXIT", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
            	ConductTest.this.finish();     
            }
    	});
    	builder.show();
    }

    // Name of the connected device
    private String mConnectedDeviceName = null;
    
    // CALLBACKS
    
    // What do do when the connect to device dialogue returns
    DialogInterface.OnClickListener connectDialogClickListener = new DialogInterface.OnClickListener() {
        public void onClick(DialogInterface dialog, int which) {
            Intent serverIntent = null;
			switch (which){
            case DialogInterface.BUTTON_POSITIVE:
            	serverIntent  = new Intent(ConductTest.this, DeviceList.class);
                startActivityForResult(serverIntent, REQUEST_CONNECT_DEVICE_SECURE);
                break;

            case DialogInterface.BUTTON_NEGATIVE:
                break;
            }
        }
    };

    // The Handler that gets information back from the BluetoothService
    private final Handler mHandler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what) {
            case   BluetoothService.MESSAGE_STATE_CHANGE:
                if(D) Log.i(TAG, "MESSAGE_STATE_CHANGE: " + msg.arg1);
                switch (msg.arg1) {
                case BluetoothService.STATE_CONNECTED:
                	finishActivity( REQUEST_CONNECT_DEVICE_SECURE );

                	
                	mPatButton.setVisibility(View.VISIBLE);
                	
                	if(connectionIndicator != null) connectionIndicator.dismiss();
                	
                	mOtherStartTest = false;
                	mStartTest = false;
                	if(D) Log.d(TAG,"mStartTest + mOther: false");
                    break;
                case BluetoothService.STATE_CONNECTING:
                case BluetoothService.STATE_LISTEN:
                case BluetoothService.STATE_NONE:
                    break;
                }
                break;
            case BluetoothService.MESSAGE_READ:
                byte[] readBuf = (byte[]) msg.obj;
                // construct a string from the valid bytes in the buffer
                // TODO: resolve the issue where both click conduct test at the same time, and two tests are initiated                
                String readMessage = new String(readBuf, 0, msg.arg1);
                if(D) Log.d(TAG, "Received the message: " + readMessage);
                
                String[] parsed_message = readMessage.split(PrivateProtocol.SEPERATOR);
                
                
                if(readMessage.equals(TEST_OK)){
                	mOtherStartTest = true;
                	if(D) Log.d(TAG,"mOtherStartTest: true");
                	
                	// This is another hack to resolve duplicate pressed states
                	//       we may want to remove double press resolution in the protocol and move it here
                	if(mStartTest){
                		if(D) Log.e(TAG, "Double press detected!!");
                		doTest(PaternityTest.TEST_NAME, true); //TODO: How do we know which test if we have multiple
                	}
                }
                
                if(mStartTest && parsed_message.length > 1 && parsed_message[0].equals(PrivateProtocol.START_TEST_MESSAGE)) 
                	doTest(parsed_message[1], false);
                break;
            case BluetoothService.MESSAGE_DEVICE_NAME:
                // save the connected device's name
                mConnectedDeviceName = msg.getData().getString(BluetoothService.DEVICE_NAME);
                Toast.makeText(getApplicationContext(), "Connected to "
                               + mConnectedDeviceName, Toast.LENGTH_SHORT).show();
                break;
            case BluetoothService.MESSAGE_TOAST:
                // For the usability test we mute tests
            	//Toast.makeText(getApplicationContext(), msg.getData().getString(BluetoothService.TOAST),
                //               Toast.LENGTH_SHORT).show();
                break;
            case BluetoothService.MESSAGE_FAILED:
            	// Reset the ui
            	mPatButton.setVisibility(View.INVISIBLE);
            	if(connectionIndicator != null) connectionIndicator.dismiss();
            	
            	Intent serverIntent = new Intent(ConductTest.this, DeviceList.class);
    	        startActivityForResult(serverIntent, REQUEST_CONNECT_DEVICE_SECURE);
    	        break;
        }
    }};
    
    
    //Called when INTENT is returned
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if(D) Log.d(TAG, "onActivityResult " + resultCode);
        switch (requestCode) {
        case REQUEST_CONNECT_DEVICE_SECURE:
            // When DeviceListActivity returns with a device to connect
            if (resultCode == Activity.RESULT_OK) {
                connectDevice(data, true);
            }
            break;
        case REQUEST_ENABLE_BT:
            // When the request to enable Bluetooth returns
            if (resultCode == Activity.RESULT_OK) {
                // Bluetooth is now enabled, so set up a chat session
                setupChat();
                
                
            } else {
                // User did not enable Bluetooth or an error occurred
                Log.d(TAG, "BT not enabled");
                Toast.makeText(this, R.string.bt_not_enabled_leaving, Toast.LENGTH_SHORT).show();
                finish();
            }
        case REQUEST_DISCOVERABLE:
        	if( resultCode == RESULT_CANCELED ){
        		// for now we do nothing
        	}
        	
	        // Launch the DeviceListActivity to see devices and do scan
	        Intent serverIntent = new Intent(this, DeviceList.class);
	        startActivityForResult(serverIntent, REQUEST_CONNECT_DEVICE_SECURE);
        }
    }
    
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.options_menu, menu);
        return true;
    }
    
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        Intent serverIntent = null;
        switch (item.getItemId()) {
        case R.id.secure_connect_scan:
        	// Launch the DeviceListActivity to see devices and do scan
            serverIntent = new Intent(this, DeviceList.class);
            startActivityForResult(serverIntent, REQUEST_CONNECT_DEVICE_SECURE);
            return true;
        case R.id.discoverable:
            // Ensure this device is discoverable by others
            ensureDiscoverable();
            return true;
        }
        return false;
    }
    
    private void connectDevice(Intent data, boolean secure) {
    	// Check that we're actually connected before trying anything
        if (mMessageService.getState() == BluetoothService.STATE_CONNECTED) {
            Toast.makeText(this, R.string.already_connected, Toast.LENGTH_SHORT).show();
            return;
        }
    	connectionIndicator = ProgressDialog.show(this, "", "Please wait while we connect you.");
    	
        // Get the device MAC address
        String address = data.getExtras()
            .getString(DeviceList.EXTRA_DEVICE_ADDRESS);
        // Get the BluetoothDevice object
        BluetoothDevice device = mBluetoothAdapter.getRemoteDevice(address);
        // Attempt to connect to the device
        mMessageService.connect(device, secure);
    }
}
