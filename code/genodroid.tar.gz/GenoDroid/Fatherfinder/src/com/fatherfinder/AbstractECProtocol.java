package com.fatherfinder;

import java.math.BigInteger;
import java.util.List;

import org.spongycastle.asn1.nist.NISTNamedCurves;
import org.spongycastle.asn1.x9.X9ECParameters;
import org.spongycastle.math.ec.ECPoint;

import android.util.Log;

/**
 * This is the base fo many elliptic curve based protocols.
 * @author skyf
 *
 */

public abstract class AbstractECProtocol extends PrivateProtocol {
	// Debug info
	private final String TAG = "AbstractECProtocol";
	private final boolean D = true;

	 //public keys
    protected ECPoint g;
    protected BigInteger n;
	
	@Override
	protected void loadSharedKeys() {
    	X9ECParameters x9 = NISTNamedCurves.getByName("P-224"); // or whatever curve you want to use
    	g = x9.getG();
    	n = x9.getN();
    	 	
 		
 		if(D) Log.d(TAG, "n: " + n);
 		if(D) Log.d(TAG, "g: " + g);

	}

  // H, as in the PCI-C protocol. Here the input is a string, and the output is an element in the curve
 	protected ECPoint hash(String input){
 		return g.multiply(hash(input.getBytes(), (byte)0).mod(n));
 	}
 	// H', as in the PCI-C protocol. The input is a ECPoint, and the output is any <160 bit integer
 	protected BigInteger hash(ECPoint input){
  		return hash(input.getEncoded(), (byte)1);
 	}
 	
}
