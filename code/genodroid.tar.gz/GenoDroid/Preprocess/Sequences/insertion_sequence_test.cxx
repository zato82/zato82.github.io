#include "gtest/gtest.h"
#include "InsertionSequence.h"
#include "BamSequence.h"


std::string DATA = "data/test/";

TEST(InsertionSequenceTest, FiltersInsertions){
  InsertionSequence s(DATA + "test_seq.bam");
  
  EXPECT_NE('T', s.current()); 
  EXPECT_NE('T', s.next());
  EXPECT_NE('G', s.next());
  EXPECT_NE('C', s.next());
  EXPECT_NE(9996, s.Position());
}
