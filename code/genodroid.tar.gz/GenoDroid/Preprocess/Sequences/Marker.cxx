//This will contain any marker specific methods (include loading and saving to files)
