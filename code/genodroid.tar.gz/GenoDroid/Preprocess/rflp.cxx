//Emulate RFLP to generate fragment lengths=
#include <string>
#include <vector>
#include <iostream>
#include <Sequence.h>
#include <Enzyme.h>
#include <BamSequence.h>
#include <StringSequence.h>

#define DEBUG true

using namespace std;

void ussage(char* argv[]){
  cout << argv[0] << "" << endl;
  cout << "EG:" << endl;
  exit(1);
}

int main(int argc, const char* argv[] )
{

  // TODO: Allow this to be a directory or list
  string bamFilename = argv[1];

  // CSV of enzymes one per line (name,string,cut position)
  string enzymeFilename = ""; //argv[2];

  // CSV of markers one per line
  string markersFilename = ""; //argv[3];


  Sequence * seq;
  vector<Enzyme *> enzymes;
  vector<Sequence *> markers;
  
  // Load the files
  try{
    seq = new BamSequence(bamFilename);
    
    // Here the cut, position is the start of the second half
    enzymes.push_back( new Enzyme("CTGCAG", "pstI", 5) );

    std::cout << "Cutting with enzyme :";
    enzymes.back()->PrintSelf(std::cout);

    markers.push_back( new StringSequence("GCTGCCCACTTCTTCCAGAGGGCCTGGCCATGGGTGAGGGCCCTGGGTAGAAGACCCC") );
  }
  // TODO: More restrictive error handling
  catch( ... ){
    cerr << "Error reading " << bamFilename << endl;
    exit(1);
  }
  
  // Have each enzyme digest the genome while checking for markers
  char read;
  int num_enzymes = enzymes.size(); // we assume the enzyme and marker list don't change
  int num_markers = markers.size();
  Sequence** fragments    = new Sequence* [num_enzymes];      // 1d arrays of pointers
  Sequence*** marked_frags= new Sequence** [num_enzymes];      // 2d arrays of pointers
  int     *  skips        = new      int    [num_enzymes];       // Handles skiping matches
  bool    ** marks        = new     bool*   [num_enzymes];       // Keeps track of when a marker has been identified.

  // Init arrays
  for( int i=0; i < num_enzymes; i++){
    
    fragments[i]    = new StringSequence("");
    marked_frags[i] = new Sequence*[num_markers];
    marks[i]        = new     bool[num_markers];
    
    for( int j=0; j < num_markers; j++){
      marked_frags[i][j]    = NULL;
      marks       [i][j]    = false;
    }
    skips[i] = 0;
  }
  
  // Loop through the genome
  read = seq->begin();
  
  std::cout << "Starting at position " << ((BamSequence *)seq)->Position() << std::endl;

  int p = 0;
  do {   
    p += 1;
    if((p % 100000 == 0) && DEBUG)
      std::cout << "Looked at " << p << "base pairs"<< read << std::endl;

    // Let the enzymes digest
    for( int i = 0; i < num_enzymes; i++ ){
      // This enzyme has found a match skip some reads
      // NOTE: This means that markers will not match over enzyme boundries
      if(skips[i] != 0){
	skips[i]--;
	continue;
      }
      
      // Check to see if the enzyme can cut at this pos in the sequence
      if ( seq->isMatch(*enzymes[i]) ){
	*(fragments[i]) += enzymes[i]->first();

	if(DEBUG){
	  std::cout << "Cut found! L = " << fragments[i]->length() << std::endl;
	  std::cout << "Pos = " << ((BamSequence *)seq)->Position();
	  std::cout<< " Read = " << seq->current() << std::endl;
	}
	bool marked = false;
	for(int m=0;m<num_markers;m++)
	  marked = marked || marks[i][m];

	// No marker is using this fragment
	if(!marked){
	  delete fragments[i];
	}

	// Init a new fragment beginning with the matched piece
	fragments[i] = new StringSequence(enzymes[i]->last());
	
	// Don't check the matching slots again (this would be biologically inacurate)
	skips[i] = enzymes[i]->length()-1;
      }
      else {
	// Collect this read onto the current fragment
	*fragments[i] += read;
      }
    }//end for enzyme

    // Check if we have found our marker
    for(int i=0; i < num_markers; i++){
      // NOTE: Skips are not as usefull here since a second match is unlikely by design
      //       and in 99% of cases would return the same fragment (but may give perf boost)
      
      if( seq->isMatch(*markers[i]) ){
	if(DEBUG)
	  std::cout << "Found a marker match" << std::endl;
	for(int e=0; e < num_enzymes;e++){
	  marks[e][i] = true;
	  
	  // Save this fragment since it is a match
	  marked_frags[e][i] = fragments[i];
	}
      }
      
    }// end for marker
  }while( read = seq->next() );

  // Process Fragments
  std::cout << "Writing out fragments" << std::endl;
  for(int e=0; e < num_enzymes; e++){
    for(int m=0; m < num_markers; m++){
      if(marked_frags[e][m] == NULL)
	std::cout << "No marker found";
      else {
	std::cout << "Markers found!";
	marked_frags[e][m]->length();
      }
    }
  }
}

